<?php

namespace App\Http\Controllers;

use App\Jobs\GoogleVisionLabelImage;
use App\Jobs\GoogleVisionRemoveFaces;
use App\Models\Category;
use App\Jobs\ResizeImage;
use App\Models\Announcement;
use Illuminate\Http\Request;
use App\Models\AnnouncementImage;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Storage;
use App\Jobs\GoogleVisionSafeSearchImage;

class AdController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }
    // ! FUNZIONI PER LE VISTE
    public function index()
    {
        return view('welcome');
    }
    
    public function newAd()
    {
        return view('ads');
    }
    
    public function announcementIndex()
    {
        return view('newann');
    }
    
   
    //! FUNZIONE PER LA CREAZIONE DELL'ANNUNCIO
    public function createAd(Request $request)
    {
        $announcement = Announcement::create([
            'name' => $request->name,
            'price' => $request->price,
            'body' => $request->body,
            'category_id' => $request->category,
        ]);
        $uniqueSecret = $request->input('uniqueSecret');
        $images = session()->get("images.{$uniqueSecret}", []);
        $removedImages = session()->get("removedimages.{$uniqueSecret}",[]);
        $images = array_diff($images, $removedImages);

        foreach ($images as $image) {
            $i = new AnnouncementImage();
            $fileName = basename($image);
            $newFileName = "public/announcements/{$announcement->id}/{$fileName}";
            Storage::move($image, $newFileName);
            $i->file = $newFileName;
            $i->announcement_id = $announcement->id;
            $i->save();
                GoogleVisionSafeSearchImage::withChain([
                new GoogleVisionLabelImage($i->id),
                new GoogleVisionRemoveFaces($i->id),
                new ResizeImage(
                    $i->file,
                    298,
                    223
                )
            ])->dispatch($i->id);
        }

        return redirect(route('welcome'))->with('message', 'Grazie per il tuo contributo!');
    }


    public function announcements()
    {
        $announcements = announcement::all()->where('is_accepted', true);
        return view('newann', compact('announcements'));
    }
    
    // ! Fuzione di dettaglio annuncio
    public function indexDetails(Announcement $announcement)
    {
        $images=AnnouncementImage::where('announcement_id', $announcement->id )->get();
        return view('detail', compact('announcement', 'images'));
    }

    //! FUNZIONI PER CARICARE PRENDERE O ELIMINARE LE IMMAGINI
    public function uploadImage(Request $request)
    {
        $uniqueSecret = $request->input('uniqueSecret');
        $fileName = $request->file('file')->store("public/temp/{$uniqueSecret}");

        dispatch(new ResizeImage(
            $fileName,
            80,
            80
        ));
        session()->push("images.{$uniqueSecret}", $fileName);
        // return response()->json(session()->get("images.{$uniqueSecret}"));
        return response()->json(
            [
                'id'=>$fileName
            ]
        );
    }

    public function removeImage(Request $request)
    {
        $uniqueSecret = $request->input('uniqueSecret');
        $fileName = $request->input('id');
        session()->push("removedimages.{$uniqueSecret}", $fileName);
        Storage::delete('$fileName');
        return response()->json('ok');
    }

    public function getImages(Request $request)
    {
        $uniqueSecret = $request->input('uniqueSecret');
        $images = session()->get("images.{$uniqueSecret}", []);
        $removedImages = session()->get("removedimages.{$uniqueSecret}", []);
        $images = array_diff($images, $removedImages);
        $data = [];
        foreach ($images as $image) {
            $data[] = [
                'id' => $image,
                'src' => AnnouncementImage::getUrlByFilePath($image, 80, 80),
            ];
        }
        return response()->json($data);
    }
}
