<?php

namespace App\Http\Controllers;

use App\Mail\AdminMail;
use App\Models\Category;
use App\Mail\ContactMail;
use App\Models\Announcement;
use Illuminate\Http\Request;
use App\Models\AnnouncementImage;
use Illuminate\Support\Facades\Mail;

class PublicController extends Controller
{
    public function welcome(Request $request){
        
        $uniqueSecret = $request->old(
            'uniqueSecret',
            base_convert(sha1(uniqid(mt_rand())), 16, 36)
        );

        // $announcement = Announcement::create([
        //     'name' => $request->name,
        //     'price' => $request->price,
        //     'body' => $request->body,
        //     'category_id' => $request->category,
        // ]);

        $categories = Category::all();
        $announcements=Announcement::orderBy('created_at', 'desc')->where('is_accepted', true)->paginate(5);
        $images=AnnouncementImage::find([]);
        
        return view('welcome', compact('categories','announcements','uniqueSecret' , 'images'));
    }

    // public function ad_detail(Announcement $announcement){
    //     $announcement= Announcement::find($announcement);
        
    //     $categories = Category::all();
    //     $announcements=Announcement::all();
    //     return view('ad_detail', compact('categories','announcements'));
    // }


    public function categories(){
        return view('categories');
    }

    public function newann(){

        $categories = Category::all();
        $announcements=Announcement::all();
        $images=AnnouncementImage::find([]);

        return view('newann', compact('categories','announcements' , 'images'));
    }

    // public function order()
    // {
    //     $announcements = Announcement::orderBy('created_at', 'desc')->paginate(5);
    //     return view("newann", compact("announcements"));
    // }

    public function adsByCategory($id){
        //  dd($id);
        $category = Category::find($id);
        $announcements = $category->announcements()->where('is_accepted', true)->get();
        return view ('categories' , compact('category' , 'announcements'));

    }

    // ! funzione ricerca

    public function search(Request $request){
        // dd($request->all());
        $q = $request->input('q');
        
        // ! da scommentare con il revisore
        $announcements = Announcement::search($q)->get();
        // dd($announcements);

        return view('search' , compact('q' , 'announcements'));
    }

    public function revisorJoin(){
        return view('revisor.revisorJoin');
    }
    

    public function revisorMail(Request $request)
    {
        // dd($request->all());
        $user = $request->input("user");
        $email = $request->input("email");
        $message = $request->input("message");
        
        $contact = compact("user","message");
        // $adminContact = compact("user","email","message");
        
        Mail::to($email)->send(new ContactMail($contact));
        // Mail::to("presto@mail.it")->send(new AdminMail($adminContact));
    
        return redirect(route('welcome'))->with("message","Grazie per averci scritto");
    }
    


    public function locale($locale){
        session()->put('locale' , $locale);
        
        return redirect()->back();
    }


}

