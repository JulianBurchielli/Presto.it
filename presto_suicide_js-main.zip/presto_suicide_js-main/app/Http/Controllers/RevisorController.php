<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\AnnouncementImage;
use Illuminate\Http\Request;

class RevisorController extends Controller
{
    //! funzione costruttore della protezione per gli utenti revisori
    public function __construct()
    {
        $this->middleware('auth.revisor');
    }
    
    public function index()
    {
        $announcement = Announcement::where('is_accepted', null)->orderBy('created_at', 'desc')->first();
        // $images=AnnouncementImage::where('announcement_id', $announcement->id )->get();
        // if (Announcement::where(null)) {
        //     return view('welcome')->with('message', 'Non ci sono annunci da revisionare');
        // }
        // $images=AnnouncementImage::all();

        return view('revisor.rIndex', compact('announcement'));
        // return view('revisor.rIndex', compact('announcement','images'));
    }

    private function setAccepted($announcement_id, $value){
        $announcement=Announcement::find($announcement_id);
        $announcement->is_accepted = $value;
        $announcement->save();
        return redirect(route('welcome'));
    }

    public function revisorAccept($announcement_id){
        return $this->setAccepted($announcement_id, true);

    }

    public function revisorReject($announcement_id){
        return $this->setAccepted($announcement_id, false);

    }
}
