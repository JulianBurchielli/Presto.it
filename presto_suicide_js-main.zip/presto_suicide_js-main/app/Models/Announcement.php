<?php

namespace App\Models;

use App\Models\User;
use App\Models\Category;
use Laravel\Scout\Searchable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Announcement extends Model
{
    use Searchable;
    public function toSearchableArray()
    {
        $announcements = $this->categories;
        $array = [
        'id'=> $this->id,
       'name'=> $this->name,
       'body'=>$this->body,
       'price'=> $this->price,
       'category_id'=> $this->category_id,
       'announcements' => $announcements,
        ];

        return $array;
    }
    use HasFactory;
    protected $fillable=[
        'name',
        'body',
        'price',
        'category_id',
    ];

    public function category(){
        return $this->belongsTo(Category::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    static public function ToBeRevisionedCount(){
        return Announcement::where('is_accepted', null)->count();
    }

    public function images(){
        return $this->hasMany(AnnouncementImage::class);
    }
}
