<?php

namespace App\Models;

use App\Models\Announcement;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Laravel\Scout\Searchable;

class Category extends Model
{

    use Searchable;
    public function toSearchableArray()
    {
        $categories = $this->announcements;
        $array = [
        'id'=> $this->id,
        'name'=> $this->name,
        'categories'=>$categories,
             ];

        return $array;
    }


    use HasFactory;
    protected $fillable=[
        'name',
    ];

    public function announcements(){
        return $this->hasMany(Announcement::class);
    }

     
}
