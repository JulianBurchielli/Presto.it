<?php

namespace Database\Seeders;

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $categories = [
            ['name'=>'Mattoni'],
            ['name'=>'Motori'],
            ['name'=>'Informatica'],
            ['name'=>'Giochi'],
            ['name'=>'Elettrodomestici'],
            ['name'=>'Libri'],
            ['name'=>'Telefoni'],
            ['name'=>'Immobili'],
            ['name'=>'Case'],
            ['name'=>'Antiquariato'],
        ];

        foreach($categories as $category){
            DB::table('categories')->insert([
                'name'=>$category['name'],
                'created_at'=>Carbon::now(),
                'updated_at'=>Carbon::now(),
            ]);
        }

    }
}
