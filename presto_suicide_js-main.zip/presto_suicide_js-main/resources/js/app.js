require('bootstrap');
window.$=window.jQuery=require('jquery');

document.Dropzone = require('dropzone');
Dropzone.autoDiscover = false;

require('./announcementImages');
