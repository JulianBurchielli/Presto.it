btnNavMenu.addEventListener ('click' , () => {
    btnNavMenu.classList.toggle('menu-btn-open')
})