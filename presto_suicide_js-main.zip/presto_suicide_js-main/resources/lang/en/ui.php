
<?php 



return [
    'revisor' => 'become a revisor',
    'ads' => 'Ads' ,
    'sign' => 'Sign In',
    'adstitle' => 'Ad Title' ,
    'price' => 'Price' ,
    'category' => 'Category' ,
    'description' => 'Description' ,
    'images' => 'Images' , 
    'Welcome to presto' => 'Welcome to' 

];
