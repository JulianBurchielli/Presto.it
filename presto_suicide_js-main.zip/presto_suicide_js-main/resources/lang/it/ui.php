<?php


return [
    'revisor' => 'Diventa un revisore' ,
    'ads' => 'Annunci' ,
    'sign' => 'Registrati' ,
    'adstitle' => 'Titolo annuncio' ,
    'price' => 'Prezzo' ,
    'category' => 'Categoria' ,
    'description' => 'Descrizione' ,
    'images' => 'Immagini' ,
    'Welcome to presto' => 'Benvenuto su'
     
];