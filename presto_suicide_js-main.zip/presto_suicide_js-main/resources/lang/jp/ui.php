

<?php


return [
    'revisor' => 'レビューア になる',
    'ads' => 'アナウンス',
    'sign' => 'アカウントを作成' ,
    'adstitle' => 'タイトル アナウンス' ,
    'price' => '価格' ,
    'category' => 'カテゴリー' ,
    'description' => '説明' ,
    'images' => '画像' ,
    'Welcome to presto' => 'いらっしゃいませ'
    
];