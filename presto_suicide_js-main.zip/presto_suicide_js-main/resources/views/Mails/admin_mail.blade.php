<h1>Grazie per la tua richiesta!</h1>
<p>Prenderemo in carico la sua richiesta il prima possibile!</p>