<x-layout>
    <div class="container py-5 vh-100">
        <div class="row">
            <div class="col">
                <h1 class="text-center fw-bold py-5">Categorie: <em>{{ $category->name }}</em></h1>
                <div class="container">
                    <div class="row">
                        @foreach ($announcements as $announcement)
                    <div class="col-4 d-flex justify-content-center">
                        <div class="card px-0 mb-5 shadow">
                            <div class="card__image-holder">
                                <div class="card-image" id="cardimage">
                                    <a type="submit" href="{{ route('detail', compact('announcement')) }}"><img
                                            class="img"
                                            src="{{ $announcement->images[0]->getUrl(298, 223) }}"></a>
                                </div>
                            </div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-6 p-0">
                                        <h4 class="card-title mt-2">{{ $announcement->name }}</h4>
                                        <p class="card-text fs-2">{{ $announcement->price }} €</p>
                                    </div>
                                    <div class="col-6 p-0">
                                        <div class="card-title">
                                            <a href="{{ route('categories', ['id' => $announcement->category->id]) }}">
                                                <h5 class="card-title text-end mt-1 fs-6">
                                                    {{ $announcement->category->name }}
                                                </h5>
                                            </a>
                                            <p class="text-end">
                                                {{ $announcement->created_at->format('d/m/y h:m:s') }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p class="text-center mb-3">
                                <a href="{{ route('detail', compact('announcement')) }}">
                                    <button class="offset">
                                        Vai all'annuncio
                                    </button>
                                </a>
                            </p>
                        </div>
                    </div>
                    @endforeach
                    </div>
                </div>
                


            </div>
        </div>
    </div>
</x-layout>