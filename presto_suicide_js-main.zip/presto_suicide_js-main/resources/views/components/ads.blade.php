<x-layout>
    <h1>Annunci</h1>
    @foreach ($announcement)
    <div class="row">
        <div class="col-sm-6">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title" name='name'>{{$announcement->name}}</h5>
              <h5 class="card-title" name='category'>{{$announcement->category}}</h5>
              <p class="card-text" name='description'>{{$announcement->description}}</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
    </div>
    @endforeach
</x-layout>