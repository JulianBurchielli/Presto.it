<footer class="container-fluid relative no-overflow text-white bg-dark footerbg">
    <div class="container py-3 py-lg-5">
        <section class="row justify-content-around py-4">
            <div class="col-12 text-center">
                <h3 class="bold mb-0" itemprop="name">Presto Srl</h3>
                <p class="bold" itemprop="address">
                    Via dei Creatori di Mattoni 5 <br>
                    09126 BrickLand (BRL)
                </p>

                <ul class="bold list-unstyled mb-4">
                    <li><i class="fa fa-phone me-2" aria-hidden="true"></i><span itemprop="telephone">00000000</span>
                    </li>
                </ul>
            </div>
            <div class="row">
                <hr>
            </div>
                <!-- Social Networks -->
                <div class="col-12 text-center">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item"><i class="fab fs-3 fa-facebook-f" aria-hidden="true"></i></li>
                    <li class="list-inline-item"><i class="fab fs-3 fa-instagram" aria-hidden="true"></i></li>
                    <li class="list-inline-item"><i class="fab fs-3 fa-whatsapp" aria-hidden="true"></i></li>
                    <li class="list-inline-item"><i class="fab fs-3 fa-twitter" aria-hidden="true"></i></li>
                    <li class="list-inline-item myIcon"><i class="fab fs-3 fa-linkedin-in" aria-hidden="true"></i></li>
                </ul>
            </div>
        </div>
        </section>
    </div>
    <section class="row">
        <div class="col-12">
            <p class="text-center">
                © 2022 <strong>Presto.it</strong> • Tutti i diritti riservati • P.IVA 124570087893 • Creator mattoni.JS •</p>
        </div>
    </section>
</footer>
