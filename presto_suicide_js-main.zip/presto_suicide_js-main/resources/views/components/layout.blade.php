<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    {{-- GoogleFonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Rowdies:wght@300;400;700&family=Ubuntu:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Zen+Kurenaido&display=swap"
        rel="stylesheet">
    <!--il mio css-->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    {{-- fontawesome --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
        integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    {{-- tag per il csrf token --}}
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>

<body class="mt-5 pt-5">
    <x-navbar />
    {{ $slot }}
    <x-footer />
    <!--il nostro javascript-->
    <script src="{{ asset('js/app.js') }}"></script>
</body>

</html>
