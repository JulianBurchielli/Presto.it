<nav class="navbar navbar-expand-lg navbar-dark bg-dark py-4 fixed-top shadow">
    <div class="container mynav">
        <a class="navbar-brand fs-3 fw-bold" href="{{ route('welcome') }}"><span
                class="text-decoration-underline fst-italic fs-1">Presto.it </span> <i
                class="text-decoration-underline fa-solid fa-truck-fast fst-italic fs-2"></i></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('newann') }}">{{ __('ui.ads') }}</a>
                </li>
                @guest
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login') }}">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">{{ __('ui.sign') }}</a>
                    </li>
                    @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('revisor_Join') }}">{{ __('ui.revisor') }}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">{{ Auth::user()->name }}</a>
                    </li>
                    {{-- parte revisore da testare --}}
                    @if (Auth::user()->is_revisor)
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('revisor_home') }}">
                                Revisor Home
                                <span class="badge badge-pill badge-warning">
                                    {{ \App\Models\Announcement::ToBeRevisionedCount() }}
                                </span>
                            </a>
                        </li>
                    @endif

                    <li class="nav-item ">
                        <a class="nav-link" href="{{ route('logout') }}"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    </li>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                    </li>
                @endguest
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Language
                    </a>
                    <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                        <li class="dropdown-item">
                            <form method="POST" action="{{ route('locale', 'it') }}">
                                @csrf
                                <button type="submit" class="nav-link text-center w-100"
                                    style='background-color:transparent; border:none;'>
                                    <span class="flag-icon flag-icon-it fs-5 myButtonWidth"></span>
                                </button>
                            </form>
                        </li>
                        <li class="dropdown-item">
                            <form method="POST" action="{{ route('locale', 'gb') }}">
                                @csrf
                                <button type="submit" class="nav-link text-center w-100"
                                    style='background-color:transparent; border:none;'>
                                    <span class="flag-icon flag-icon-gb fs-5 myButtonWidth"></span>
                                </button>
                            </form>
                        </li>
                        <li class="dropdown-item">
                            <form method="POST" action="{{ route('locale', 'jp') }}">
                                @csrf
                                <button type="submit" class="nav-link text-center w-100"
                                    style='background-color:transparent; border:none;'>
                                    <span class="flag-icon flag-icon-jp fs-5 myButtonWidth"></span>
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>

            <form method="GET" action="{{ route('search') }}" class="d-flex">
                <input class="form-control rounded-pill" type="text" name="q" placeholder="Search">
                <button class="raise rounded-pill py-2" type="submit">Cerca</button>
            </form>

        </div>
    </div>
</nav>
