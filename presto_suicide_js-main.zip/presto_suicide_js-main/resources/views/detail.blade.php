<x-layout>
    <div class="container py-5 text-center">

        <div class="row justify-content-center">
            <div class="col-7 min-vh-100 shadow">
                <div class="row">
                    @foreach ($images as $image)
                        <div class="col m-3">
                            <img src="{{ $image->getUrl(298, 223) }}" class="rounded shadow">
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="col-5 shadow">
                <h1 class="py-5 fw-bold">
                    Dettagli dell'annuncio
                </h1>
                <div class="">
                    <h5 class="card-title fs-3 py-3">Titolo: {{ $announcement->name }}</h5>
                    <p class="card-text fs-4 py-3">Descrizione: {{ $announcement->body }}</p>
                    <p class="card-text fs-3 py-3">Prezzo: {{ $announcement->price }} €</p>
                    <p class="fs-4 py-3">Categoria:
                        <a href="{{ route('categories', ['id' => $announcement->category->id]) }}">
                            <span class="card-title fst-italic mt-1 fs-3">
                                {{ $announcement->category->name }}
                            </span>
                        </a>
                    </p>
                    <p class="fs-5 py-3">Data di creazione: {{ $announcement->created_at }}</p>
                </div>
            </div>
        </div>
    </div>

</x-layout>
