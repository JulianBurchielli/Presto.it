<x-layout>
    @if($announcement)
    <div class="container py-5">
        <h1 class="text-center py-5 fw-bold">
            Dettagli dell'annuncio: <em>{{$announcement->name}}</em>
        </h1>
        <div class="row py-3 shadow">
            <div class="col-10">
                @foreach ($announcement->images as $image)
                    <div class="row mb-2">
                        <div class="col">
                            <img src="{{$image->getUrl(298, 223)}}" class="rounded">
                        </div>
                        <div class="col">
                            
                            Adult: {{$image->adult}}<br>
                            Medical: {{$image->medical}}<br>
                            Spoof: {{$image->spoof}}<br>
                            Violence: {{$image->violence}}<br>
                            Racy: {{$image->racy}}<br>
                        </div>

                            <div class="col">
                            <b>Labels:</b><br>
                            <ul>
                                @if ($image->labels)
                                @foreach ($image->labels as $label)
                                    <li>{{$label}}</li>
                                @endforeach
                                @endif
                            </ul>
                        </div>
            
            
                    </div>
                @endforeach
            </div>
            <div class="col">
                <h5 class="card-title">{{ $announcement->name }}</h5>
                <p class="card-text">{{ $announcement->body }}</p>
                <p class="card-text">{{ $announcement->price }} €</p>
                <p>{{ $announcement->created_at }}</p>
                <p>{{ $announcement->category->name }}</p>
                <form action="{{ route('revisor_accept', $announcement->id) }}" method="POST" class="text-center">
                    @csrf
                    <button class="offset" type="submit">Accetta</button>
                </form>
                <form action="{{ route('revisor_reject', $announcement->id) }}" method="POST" class="text-center">
                    @csrf
                    <button class="offset" type="submit">Rifiuta</button>
                </form>
            </div>
        </div>
    </div>
    @else
    <div class="container text-center vh-100 py-5 mt-5">
        <h2 class="fw-bold text-success">Non ci sono annunci</h2>
    </div>
    @endif
    
    
</x-layout>