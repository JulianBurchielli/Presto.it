<x-layout>
    <div class="container py-5">
        <div class="row">
            <h1 class="text-center fw-bold py-5">Vuoi diventare Revisor?</h1>
            <div class="col">
                <img src="/img/revisor.svg" alt="" class="img-fluid">
                <p class="text-center fs-2">Lavora con noi!</p>
            </div>
            <div class="col-6 shadow px-5">
                <form method="POST" action="{{ route('revisor_Join') }}" class="py-5 mt-5">
                    @csrf
                    <div class="mb-3 py-2">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" name="email">
                    </div>
                    <div class="mb-3 py-2">
                        <label for="exampleInputPassword1" class="form-label">Nome e Cognome</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="user">

                        <div class="mb-3 py-5">
                            <label for="exampleInputPassword1" class="form-label">Parlaci di te!</label><br>
                            <textarea type="text" id="" cols="30" rows="10" class="form-control"
                                name='message'></textarea>
                        </div>
                        <p class="text-center">
                            <button type="submit" class="offset">Invia</button>
                        </p>
                </form>
            </div>
        </div>
    </div>
</div>

</x-layout>
