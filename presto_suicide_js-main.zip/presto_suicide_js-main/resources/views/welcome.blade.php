<x-layout>
    <header class="masthead position-relative vh-100">
        <div class="container-fluid py-5">
            <div class="row">
                @if (session('message'))
                    <div class="alert alert-success">
                        {{ session('message') }}
                    </div>
                @endif
                <div class="col-5">

                    <h1 class="text-center"> {{ __('ui.Welcome to presto') }}<span class="fst-italic fw-bold">
                            Presto.it</span></h1>
                            <div>
                                <p class="text-center fs-4 mt-4">Sei in cerca di affari? </p>
                            </div>
                            <div>
                                <p class=" text-center fs-4 mt-3">Vuoi vendere la bici della comunione?</p>
                            </div>
                            <div>
                                <p class=" text-center fs-4 mt-3">Questo è il posto giusto per te</p>
                            </div>

                </div>

                {{-- Nuovo form --}}
                <div class="col-1"></div>

                <div class="login-wrap py-3 mb-5 h-100">
                    <div class="login-html text-center h-100">
                        <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1"
                            class="tab fs-2 px-3 text-center">Compra</label>
                        <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2"
                            class="tab fs-2 px-3 text-center">Vendi</label>
                        <div class="login-form h-100">
                            <div class="sign-in-htm">
                                <div class="group">
                                    <label for="user" class="label py-5 text-center text-white fs-3">Cerca per
                                        titolo</label>
                                    <form method="GET" action="{{ route('search') }}" class="d-flex">
                                        <input id="user" class="input" type="text" name="q"
                                            placeholder="Search">
                                        <button class="raise rounded-pill py-1" type="submit">Cerca</button>
                                    </form>
                                    <div class="col-12 text-center py-3 mt-3">
                                        <label for="user" class="label py-5 fs-3 text-white">Cerca per categorie</label>
                                        @foreach ($categories as $category)
                                            <a href="{{ route('categories', ['id' => $category->id]) }}">
                                                <button class="up" type="submit">
                                                    {{ $category->name }}
                                                </button>
                                            </a>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                            <div class="sign-up-htm h-100">

                                <form action="{{ route('adcreate') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="uniqueSecret" value="{{ $uniqueSecret }}">
                                    <div class="group h-100">
                                        <label for="user" class="label py-2">{{ __('ui.adstitle') }}</label>
                                        <input id="user" type="text" class="input" name='name'>
                                        @error('name')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="group">
                                        <label for="user" class="label py-2">{{ __('ui.price') }}</label>
                                        <input id="user" type="number" class="input" name='price'>
                                    </div>
                                    <div class="group">
                                        <label for="user" class="label py-2">{{ __('ui.category') }}</label>
                                        <br>
                                        <select id="user" class="input py-2 text-center" name="category" id="category">
                                            @foreach ($categories as $category)
                                                <option class="bg-dark text-center" value="{{ $category->id }}">
                                                    {{ $category->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="group h-100">
                                        <label for="user"
                                            class="label">{{ __('ui.description') }}</label><br>
                                        <input id="user" class="input" name="body" class="form-control">
                                    </div>
                                    <div class="group h-100">
                                        <label for="user" class="label py-2">
                                            {{ __('ui.images') }}
                                        </label>
                                        <div class="col-md-12 myScrollDrop w-100">
                                            <div class="dropzone myScrollBox" id="drophere"></div>
                                            @error('images')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <p class="text-center py-3">
                                        <button type="submit" class="raise">Pubblica
                                            l'annuncio</button>
                                    </p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid py-3 myNewAnn">
        <div class="row justify-content-evenly">
            <div class="col-12">
                <h1 class="text-center fw-bold py-5">Nuovi annunci</h1>
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    @foreach ($announcements as $announcement)
                        <div class="col-4 d-flex justify-content-center">
                            <div class="card px-0 mb-5 shadow">
                                <div class="card__image-holder">
                                    <div class="card-image" id="cardimage">
                                        <a type="submit" href="{{ route('detail', compact('announcement')) }}"><img
                                                class="img"
                                                src="{{ $announcement->images[0]->getUrl(298, 223) }}"></a>
                                    </div>
                                </div>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6 p-0">
                                            <h4 class="card-title mt-2">{{ $announcement->name }}</h4>
                                            <p class="card-text fs-2">{{ $announcement->price }} €</p>
                                        </div>
                                        <div class="col-6 p-0">
                                            <div class="card-title">
                                                <a
                                                    href="{{ route('categories', ['id' => $announcement->category->id]) }}">
                                                    <h5 class="card-title text-end mt-1 fs-6">
                                                        {{ $announcement->category->name }}
                                                    </h5>
                                                </a>
                                                <p class="text-end">
                                                    {{ $announcement->created_at->format('d/m/y h:m:s') }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <p class="text-center mb-3">
                                    <a href="{{ route('detail', compact('announcement')) }}">
                                        <button class="offset">
                                            Vai all'annuncio
                                        </button>
                                    </a>
                                </p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="d-none">
                {{ $announcements->links() }}
            </div>
        </div>
    </div>


</x-layout>
