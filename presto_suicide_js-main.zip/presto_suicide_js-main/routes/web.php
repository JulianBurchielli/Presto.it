<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdController;

use App\Http\Controllers\PublicController;
use App\Http\Controllers\RevisorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// ! Rotte per la visualizzazione
Route::get('/',[PublicController::class, 'welcome'])->name('welcome');
Route::get('/categories/{id}',[PublicController::class, 'adsByCategory'])->name('categories');


// ! Rotte per gli Ads
Route::post('/ads/create',[AdController::class, 'createAd'])->name('adcreate');
Route::get('/newann',[AdController::class, 'announcements'])->name('newann');
Route::post('/', [AdController::class, 'announcementIndex'])->name('welcome');

// !rotte per aggiungere ed eliminare immagini

Route::post("/announcement/images/upload", [AdController::class, 'uploadImage'])->name('images_upload');
Route::delete("/announcement/images/remove", [AdController::class, 'removeImage'])->name('images_remove');
Route::get("/announcement/images", [AdController::class, 'getImages'])->name('image_announcement');


// ! Rotta per i dettagli degli annunci
Route::get('/welcome/detail/{announcement}',[AdController::class, 'indexDetails'])->name('detail');

// !Rotta per la ricerca
Route::get('/search' , [PublicController::class , 'search'])->name('search');

// !Rotte per revisore
Route::get('/revisor/home', [RevisorController::class, 'index'])->name('revisor_home');
Route::post('/revisor/announcement/{id}/accept', [RevisorController::class, 'revisorAccept'])->name('revisor_accept');
Route::post('/revisor/announcement/{id}/reject', [RevisorController::class, 'revisorReject'])->name('revisor_reject');

//!Rotta per diventare revisore
Route::get('/revisorJoin', [PublicController::class, 'revisorJoin'])->name('revisor_Join');
Route::post('/revisorJoin', [PublicController::class, 'revisorMail'])->name('revisor_Join');

// !Rotte cambio lingua
Route::post('/locale/{locale}' , [PublicController::class , 'locale'])->name('locale');